package com.example.taller02a

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.auth.*

enum class ProviderType{
    BASIC
}


class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.auth)
        val bundle: Bundle? = intent.extras
        val email: String? = bundle?.getString("email")
        val proveedor: String? = bundle?.getString("proveedor")
        setup(email ?: "", proveedor ?: "")

    }
    private fun setup(email: String, proveedor: String){
        title = "Inicio"
        emailtextView.text = email
        proveedortextView2.text = proveedor
        logOutbutton.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            onBackPressed()
        }
    }

}
